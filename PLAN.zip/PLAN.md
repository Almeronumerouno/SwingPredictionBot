# Swing Bot IDX — Execution Plan v0.3.0

## Ringkasan

Fase 7: Production Readiness. Urutan pengerjaan dikunci berdasarkan dependensi — walk-forward harness dibuat pertama sebagai fondasi validasi, baru parameter lain ditumpuk di atasnya.

## Sequencing (Wajib)

| Sprint | Item | Parameter Baru | Dependensi |
|--------|------|:--------------:|------------|
| **S1A** | Walk-forward harness skeleton | 0 | — |
| **S1B** | Fix R:R — TP multiplier 3.0 (R:R 1:1) | 1 | S1A |
| **S1C** | Breakeven stop — SL ke entry setelah profit 1.0 ATR | 1 | S1A |
| **S1D** | Long-only mode — SELL jadi advisory, nonaktifkan short entry | 0 | — |
| **S2** | Rekonsiliasi position sizing (25% vs 100%) + validasi semua S1 via harness | 0 | S1A–D |
| **S3** | Regime detection (SMA200 + ADX) + regime-dependent weights & sizing | 2-3 | S2 |
| **S4+** | Full scale-out 3-tier, trailing stop, ML | banyak | S3 terbukti OOS |

**Aturan:** Tiap sprint hanya jalan setelah sprint sebelumnya divalidasi OOS via walk-forward harness. Tidak ada parameter baru yang ditumpuk sebelum divalidasi.

## Detail Sprint

### S1A — Walk-Forward Harness

Ekstensi `backtest.py` → `walkforward.py`

- Split data per saham ke N rolling window (6 bulan train + 3 bulan test)
- Purge 20 hari sebelum test window, embargo 20 hari antara train dan test
- Setiap window: optimize train → test di OOS
- Concat SEMUA OOS trade dari seluruh (saham × window) jadi 1 equity curve
- Output: metrik final OOS (Win Rate, Sharpe, Return, Max DD)
- Output sampingan: parameter stability (stdev parameter optimal antar window)
- Target: harness berfungsi & reproducible sebelum S1B mulai

### S1B — Fix R:R Ratio

- `config.py`: `ATR_TP_MULTIPLIER = 3.0` (dari 2.5) → R:R 1:1
- Opsi: `ATR_TP_MULTIPLIER = 3.5` → R:R 1.17:1
- Bandingkan TP hit rate lama (40.4%) vs baru via harness S1A

### S1C — Breakeven Stop Rule

- 1 parameter baru: `BREAKEVEN_TRIGGER = 1.0` (ATR multiplier)
- Di `backtest.py`: setelah entry, jika harga menyentuh target, pindahkan SL ke entry price
- Aman — hanya 1 parameter, logika sederhana

### S1D — Long-Only Mode

- `config.py`: `LONG_ONLY_MODE = True` (default)
- `risk.py`: jika `LONG_ONLY_MODE` dan recommendation = SELL, return None
- `api.py`: SELL tetap tampil di scoring sebagai advisory, `validation_note` menjelaskan
- **0 parameter tuning** — logical toggle

### S2 — Rekonsiliasi Position Sizing

- Dokumen (PRD/README) bilang 25%, kode `risk.py:44` pakai `deploy_pct = 1.0`
- Luruskan: pilih 100% dari capital yang di-input user (frontend CapitalControl sudah handle)
- Update semua dokumentasi agar konsisten
- Validasi: jalanin semua S1 lewat harness, bandingkan metrik OOS

### S3 — Regime Detection & Adaptive Parameters

```python
def detect_regime(close, adx):
    sma200 = mean(close[-200:])
    trend = "bull" if close[-1] > sma200 else "bear"
    if adx[-1] < 20: trend = "sideways"
    return trend
```

| Regime | Trend W | Mom W | Vol W | PA W | Buy Threshold | Position Size |
|--------|---------|-------|-------|------|:-------------:|:------------:|
| **Bull** | 0.35 | 0.25 | 0.15 | 0.25 | 75 | 100% |
| **Sideways** | 0.15 | 0.15 | 0.25 | **0.45** | 70 | 50% |
| **Bear** | 0.15 | **0.30** | 0.30 | 0.25 | N/A (long-only) | 25% |

### S4+ — Ditunda (menunggu bukti OOS dari S1-S3)

- Full scale-out 3-tier (50/30/20 + trailing)
- Dynamic ATR multiplier (volatility-adjusted)
- XGBoost feature weighting
- Ensemble scoring (3 config voting)
- HMM regime detection

## Target v0.3.0

| Metrik | v0.2.0 | Target S1-S2 | Target S3 | Target S4+ |
|--------|:------:|:------------:|:---------:|:----------:|
| Win Rate | 55.3% | 55-58% | >60% | >62% |
| TP_HIT rate | 40.4% | >50% | >55% | >60% |
| R:R rata-rata | 0.83 | 1.0+ | 1.2+ | 1.5+ |
| Sharpe | 0.24 | 0.30-0.40 | >0.50 | >0.60 |
| Max DD | 5.94% | <5.5% | <5% | <4.5% |

## Catatan

- **BUY belum tervalidasi** edge independen lintas rezim — regime detection (S3) adalah mitigasi utama
- **SELL tervalidasi** (58% WR) — long-only mode (S1D) memastikan SELL jadi advisory, bukan short entry
- Semua keputusan parameter baru harus bisa dijelaskan secara rule-based — ML hanya sebagai lapisan final opsional
